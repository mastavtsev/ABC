#ifndef HEADER_H
#define HEADER_H
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <math.h>
double f(double a, double b, double x);
int calc_n(double a, double b);
double simpsonIntegral(double a, double b, int n);
void getData(int* type, double* a, double* b, int* argc, char **argv);
void getRandomRange(double* a, double* b, char* arg);
#endif