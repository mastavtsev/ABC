#include "header.h"

void getData(int* type, double* a, double* b, int* argc, char **argv) {
    
    int ch;
    int flag = 0;
    char* fname;
    FILE *input;
    char *arg;
  
    
    if (*type == 1) {
        printf("Enter in console range of integration - two numbers A and B. \n"
               "There are two limitations for them, if they are not observed, the program ends with code 1 \n"
               " - None of the ranges must be zero, so A != 0 and B !=0 \n"
               " - Range of integration A must be grater than B \n"
               "Input A and B:   ");
               
        scanf("%lf", a);
        scanf("%lf", b);
    } else if (*type == 2) {
        fname = argv[2];
        input = fopen(fname, "r");
        if (input == NULL) {
            perror("Failed to open file!");
        }

        fscanf(input, "%lf", a);
        fscanf(input, "%lf", b);
    } else { 
        arg = argv[1];
        getRandomRange(a, b, arg);
    }

    
    if (*type == 2) {
        fclose(input);
    }
}