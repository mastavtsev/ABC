#include "header.h"
double f_d4(double x, double b) {
    double new_x = pow(x, -6);
    return 120 * b * new_x;
}


int calc_n(double a, double b) {
    double f_a = 0;
    double f_b = 0;
    double max_val;
    double diff_10;
    double temp;
    int n;
    
    f_a = f_d4(a, b);
    f_b = f_d4(b, b);
    
    if (b > 0) {
        max_val = fmax(f_a, f_b);
    } else {
        max_val = fmin(f_a, f_b);
        max_val = abs(max_val);
    }
    
    
    diff_10 = pow((b-a), 10);
    
    temp = pow((max_val * max_val * diff_10) / 0.000324, 1.0/8);

    n = ceil(temp);
    
    return n;
}