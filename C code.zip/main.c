#include "header.h"

double f(double a, double b, double x) {
    return a + b * (1/(x*x));
}

double timespecDiff(struct timespec start, struct timespec stop) {
 struct timespec ret;
 double result;
 ret.tv_sec = start.tv_sec - stop.tv_sec;
 ret.tv_nsec = start.tv_nsec - stop.tv_nsec;

 result = ret.tv_sec;
 result *= 1000000000;
 result += ret.tv_nsec;
 
 return result;
}

int main(int argc, char **argv)
{
    int type;
    int repeat;
    int i;
    double a;
    double b;
    double result;
    double elapsed_ns;
    FILE *output;
    
    struct timespec start;
    struct timespec end;
    
    
     if (argc < 3) { // exit with error
        printf("Arguments should contain seed and name of input file! \n");
		return 1;
	}
	
	if (argc == 4) {
	    repeat = atoi(argv[3]);
	} else {
	    repeat = 1;
	}
	
    printf("Type in the console the type of input you want: \n"
	"1 - console (output in console) \n"
	"2 - file input (output in output.txt) \n"
	"3 - random input (output in console) \n");
	

	scanf("%d", &type);
    
    if (type != 1 & type != 2 & type != 3) {
        printf("Incorrect type of input!");
        return 1;
    }
	
	getData(&type, &a, &b, &argc, argv);
	
	clock_gettime(CLOCK_MONOTONIC, &start);
	
	
	if (a > b) {
	    printf("A is grater B!");
	    return 1; // exit with error
	}
	
	if (a == 0 || b == 0) {
	    printf("The integral diverges!");
	    return 0; 
	}
	
	if (a < 0 & b > 0) {
	    printf("The integral diverges!");
	    return 0;
	}
	
	for (i = 0; i < repeat; i++) {
	    int n = calc_n(a, b);
	    result = simpsonIntegral(a, b, n);
	}

    clock_gettime(CLOCK_MONOTONIC, &end);
    elapsed_ns = timespecDiff(end, start);
    
	if (type != 2) {
        printf("\nIntegral value: %f", result);
    } else if (type == 2) {
        printf("\nIntegral value: %f", result);
        output = fopen("output.txt", "w");
        fprintf(output, "%f", result);
    }

    if (elapsed_ns < 10000000) {
        printf("\nElapsed: %lf ns\n", elapsed_ns);
    } else {
        elapsed_ns = elapsed_ns / 10000000; 
        printf("\nElapsed: %lf ms\n", elapsed_ns);
    }
    
    
    return 0;
}

