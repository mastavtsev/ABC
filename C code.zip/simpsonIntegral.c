#include "header.h"

double simpsonIntegral(double a, double b, int n) {
    double width = (b-a) / n;
    double x1;
    double x2; 
    
    double result = 0;
    for (int i = 0; i < n; i++) {
        x1 = a + i*width;
        x2 = a + (i+1)*width;
        
        result += (x2-x1)/6.0*(f(a, b, x1) + 4.0*f(a, b, 0.5*(x1+x2)) + f(a, b, x2));
    }
    
    return result;
}