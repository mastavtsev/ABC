#include "header.h"

void getRandomRange(double* a, double* b, char* arg) {
    int seed;
	
	FILE *output;
	
	int sign;
	int temp;
	
	seed = atoi(arg);
	srand(seed);
	
	// sign == 0 - positive ranges
	// sign == 1 - negative ranges
	sign = rand() % 2;
	
	
	*b = rand();
	*a = rand() % (int)*b + 0.0001;
	
	if (sign == 1) {
	    temp = -((int)*b);
	    *b = -(*a);
	    *a = temp;
	} 
    

    output = fopen("random_gen.txt", "w");
    fprintf(output, "%f %f", *a, *b);
}